# JARVIS – Sony Xperia 1 V starter

Version: 0.1.0  
Package: `com.jps.jarvis`  
Target: Android 16 (API 36), min Android 10 (API 29)  
Implementation: Kotlin + Jetpack Compose

## Included in this first development stage

- Original dark/cyan JARVIS interface.
- Push-to-talk speech recognition, requesting microphone permission at runtime.
- Small local command set: hello, time, open Android settings, open camera, battery level.
- Android Text-to-Speech output.
- Voice selection from voices already installed on the phone.
- Initial Android `VoiceInteractionService` and session-service declarations.
- Request to become the default Android assistant.

## Not included yet (do not mistake these for working features)

- Custom "Hey JARVIS" always-on wake word.
- Guaranteed locked-screen hotword operation.
- Cloud AI backend or API credentials.
- Full system-level privileges.
- Background microphone service.

These are deliberately deferred until the first APK is installed and tested. Third-party apps cannot assume access to privileged DSP hotword APIs. The default-assistant role is not equivalent to a preinstalled privileged system assistant.

## Build a debug APK in GitHub Actions (phone-only workflow)

1. Create a new empty GitHub repository from the GitHub mobile website.
2. Upload the contents of this project ZIP to the repository (extract the ZIP first if GitHub's upload interface requires it).
3. Open the repository's **Actions** tab.
4. Run the workflow named **Build JARVIS debug APK**.
5. Download the `JARVIS-debug-apk` artifact from the completed workflow.
6. Extract it and install `app-debug.apk` on the Xperia 1 V. Allow installation from that source when Android prompts.

The workflow uses GitHub-hosted build machines; no laptop or local Android SDK is needed.

## Local build (if Android Studio is available)

Use JDK 17, Android SDK Platform 36, Build Tools 36.0.0 and Gradle 8.13:

```bash
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

## First test checklist

- Launch JARVIS.
- Grant microphone permission.
- Tap **TAP TO SPEAK** and test "What time is it?"
- Test "Open settings", "Open camera", and "Battery".
- Select another installed TTS voice and tap **TEST VOICE**.
- Try **SET AS DEFAULT ASSISTANT** and note whether Sony's Android build offers JARVIS in the assistant selection screen.

## Privacy and safety

- The first version does not continuously record audio.
- Speech recognition behavior depends on the speech-recognition provider installed on the phone; `EXTRA_PREFER_OFFLINE` is a preference, not a guarantee.
- No audio is deliberately uploaded by this app's own code to a JARVIS server.
- No API keys or personal data are embedded in the project.
