package com.jps.jarvis

import android.service.voice.VoiceInteractionService

/**
 * Initial default-assistant integration point.
 * Custom third-party hotword DSP access is not assumed here.
 */
class JarvisVoiceInteractionService : VoiceInteractionService()
