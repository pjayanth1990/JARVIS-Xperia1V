package com.jps.jarvis

import android.service.voice.VoiceInteractionSession

class JarvisVoiceInteractionSession(context: android.content.Context) :
    VoiceInteractionSession(context)
